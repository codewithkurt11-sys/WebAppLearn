import { createClient, type SupabaseClient } from "@supabase/supabase-js";

const url = import.meta.env.VITE_SUPABASE_URL as string;
const key = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabaseEnabled = !!(url && key);

export const supabase = (
  supabaseEnabled ? createClient(url, key) : null
) as SupabaseClient;
